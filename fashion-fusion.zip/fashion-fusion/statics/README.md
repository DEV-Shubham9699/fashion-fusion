# 🖼️ Project Screenshots

## Signup
![Product Details](signup.png)

## Signin
![Product Details](signin.png)

## User Profile
![User Profile](user-profile.png)

## Home Page
![Home Page](home.png)

## Product Categories
![Product Details](clothcategory.png)

## Man's Ware
![Product Details](man'sware.png)

## Woman's Ware
![Product Details](woman'sware.png)

## Kids Ware
![Product Details](kidsware.png)

## Product Details
![Product Details](productdetail.png)

## Product Cart
![Product Cart](productcart.png)

## Place Order
![Product Details](placeorder.png)

## Order Invoice
![Product Details](user-invoice.png)

## Admin Profile
![User Profile](admin-profile.png)

## Admin Dashboard
![Admin Dashboard](admin-dashbord.png)

## User Logs
![User Profile](admin-users.png)

## Manage Products
![User Profile](admin-manage-product.png)

## Orders
![User Profile](orders.png)

## Pending Orders
![User Profile](pendingorders.png)

## Approved Orders
![User Profile](approvedorder.png)
