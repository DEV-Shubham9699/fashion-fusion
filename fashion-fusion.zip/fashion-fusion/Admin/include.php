<?php
$con=mysqli_connect("localhost","root","","fashionfusion");
if(!$con)
{
die("Failed to coonect");
}
?>